package javaoops;

public class Circleclass {
	    private double radius;
	    private String unit;

	    public Circleclass() {
	        this.radius = 1.0; 
	        this.unit = "cm"; 
	    }
	    public Circleclass(double radius, String unit) {
	        this.radius = radius;
	        this.unit = unit;
	    }
	    public void setRadius(double radius) {
	        this.radius = radius;
	    }
	    public double getRadius() {
	        return radius;
	    }
	    public void setUnit(String unit) {
	        this.unit = unit;
	    }
	    public String getUnit() {
	        return unit;
	    }
	    
	    public double getCircumference() {
	        return 2 * Math.PI * radius;
	    }
	    public static void main(String[] args) {
	        Circleclass defaultCircle = new Circleclass();
	        System.out.println("Default Circle:");
	        System.out.println("Radius: " + defaultCircle.getRadius()+ " " + defaultCircle.getUnit());
	        System.out.println("Circumference: " + defaultCircle.getCircumference());

	        Circleclass customCircle = new Circleclass(7.0, "mm");
	        System.out.println("\nCustom Circle:");
	        System.out.println("Radius: " + customCircle.getRadius()+ " " + customCircle.getUnit());
	        System.out.println("Circumference: " + customCircle.getCircumference());
	    }
}



