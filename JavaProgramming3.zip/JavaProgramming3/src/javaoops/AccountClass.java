package javaoops;

public class AccountClass {
	    private String accountNumber;
	    private double balance;

	    public AccountClass() {
	        this.accountNumber = "101000"; 
	        this.balance = 500.0;           
	    }

	    public AccountClass(String accountNumber, double balance) {
	        this.accountNumber = accountNumber;
	        this.balance = balance;
	    }

	    public void deposit(double amount) {
	        if (amount > 0) {
	            balance += amount;
	            System.out.println("Deposited: " + amount);
	        } else {
	            System.out.println("Invalid deposit amount.");
	        }
	    }

	    public void withdraw(double amount) {
	        if (amount > 0 && amount <= balance) {
	            balance -= amount;
	            System.out.println("Withdrawn: " + amount);
	        } else {
	            System.out.println("Invalid withdraw amount or insufficient balance.");
	        }
	    }
	    public double checkBalance() {
	        return balance;
	    }

	    public static void main(String[] args) {
	    	AccountClass defaultAccount = new AccountClass();
	        System.out.println("Default Account:");
	        System.out.println("Account Number: " + defaultAccount.accountNumber);
	        System.out.println("Initial Balance: " + defaultAccount.checkBalance());

	        defaultAccount.deposit(500);
	        defaultAccount.withdraw(100);
	        System.out.println("Balance after transactions: " + defaultAccount.checkBalance());

	        AccountClass customAccount = new AccountClass("123456", 1000.0);
	        System.out.println("\nCustom Account:");
	        System.out.println("Account Number: " + customAccount.accountNumber);
	        System.out.println("Initial Balance: " + customAccount.checkBalance());

	        customAccount.deposit(300);
	        customAccount.withdraw(200);
	        System.out.println("Balance after transactions: " + customAccount.checkBalance());
	    }
}



